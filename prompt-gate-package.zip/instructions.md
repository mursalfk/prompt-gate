# CB Speed Run 2: prompt gate article, instructions

Today is Nov 17. Publish window is Nov 16 to 23, then submit in the Speed Run Space and the Pulse form.

Everything is ready. The article uses your real results, so there is nothing left to run.

## What is in the package

| Path | What it is |
|---|---|
| `article.md` | The article, ready to paste. About 6,100 words including tables and code. |
| `listing.md` | Title, short description, description, tags, bio, and alt text for every image. |
| `images/` | 12 Circuit Board figures and 6 terminal screenshots, numbered in order of appearance. |
| `code/` | The repo, including your `results/`, `results-fence-ok/` and the recordings. |
| `prompt-gate-code.zip` | Just the `code/` folder, zipped, for uploading to GitHub. |

## Step 1: put the repo on GitHub (10 minutes)

1. Create a public repo called `prompt-gate`. Upload the **contents** of `code/`, including `results/` (the pull request workflow replays it).
   - Description: A regression gate for prompt changes and model swaps: graders, noise-aware stats, token and cost checks, replay cache. Python, no dependencies.
   - Topics: `llm`, `prompt-engineering`, `evals`, `regression-testing`, `github-actions`, `ollama`, `python`
2. Commit as yourself. No `Co-Authored-By` or `Claude-Session` lines in the message.
3. Optional but worth it: open one test pull request and read the Actions run page.
   - The workflow replays `examples/prompts/v5_reword.txt`, so it should pass.
   - To see a block, open a second pull request that changes `CANDIDATE_PROMPT` in `.github/workflows/prompt-gate.yml` to `examples/prompts/v3_tidy.txt`.
   - The article currently says the workflow has not been run on GitHub. If you ran it, tell me what you saw, or edit that sentence and the matching bullet under "Where this stops".

## Step 2: publish the article (10 minutes)

1. Open `listing.md`. Copy the title, short description, description and tags into Builder Center.
2. Paste `article.md`. Wherever you see `[FIGURE: filename]` or `[COVER: filename]`, upload that file from `images/` and use the italic line under it as the caption. The alt text for each is in `listing.md`.
3. Replace `[REPO LINK]` (once, near the end) with your repo link.
4. Bio, 100 characters or fewer: `AWS Community Builder (ML/AI), 6th year. AI Systems Architect. Tested AWS AI guides you can run free`
5. Publish. Open the live page on a phone and on a laptop. Check that the tables render and the images are in order.

## Step 3: submit

Submit the live article link in the Speed Run Space and in the Pulse form, before Nov 23.

## If something looks off

- A number you want to double-check lives in `code/results/summary.md` and `code/results/openai-<model>/<prompt>.json`. Every number in the article comes from those files.
- To reproduce the numbers without a GPU, run `python tools/run_matrix.py run --models llama3.2:3b --cache-mode replay` from `code/`. It replays your recordings and makes no model calls.
- The offline tests run with `python test_promptgate.py`. They need no model and no packages (`boto3` is optional, and without it one test skips).
